import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import pool from '../config/db.js'

export const register = async (req, res) => {
  const { email, password, name, preferences = [] } = req.body || {}
  if(!email || !password) return res.status(400).json({ error: 'Email and password are required' })
  try {
    const hash = await bcrypt.hash(password, 10)
    const q = `INSERT INTO users (email, password, name, preferences) VALUES ($1,$2,$3,$4) RETURNING id, email, name, preferences, variant`
    const { rows } = await pool.query(q, [email, hash, name, preferences])
    return res.status(201).json({ user: rows[0] })
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Email already exists' })
    console.error(err)
    return res.status(500).json({ error: 'Registration failed' })
  }
}

export const login = async (req, res) => {
  const { email, password } = req.body || {}
  if(!email || !password) return res.status(400).json({ error: 'Email and password are required' })
  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email])
    const user = rows[0]
    if (!user) return res.status(404).json({ error: 'User not found' })
    const match = await bcrypt.compare(password, user.password)
    if (!match) return res.status(401).json({ error: 'Invalid password' })
    const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' })
    return res.json({ token, user: { id: user.id, email: user.email, name: user.name } })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ error: 'Login failed' })
  }
}

export const me = async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, email, name, preferences, variant FROM users WHERE id=$1', [req.user.id])
    return res.json(rows[0] || null)
  } catch (err) {
    console.error(err)
    return res.status(500).json({ error: 'Failed to load profile' })
  }
}
