import { Router } from 'express'
import pool from '../config/db.js'
const r = Router()

r.get('/', async (req,res)=>{
  const { category } = req.query
  try{
    if(category){
      const { rows } = await pool.query('SELECT id, name, description, category, price FROM products WHERE category=$1 ORDER BY created_at DESC', [category])
      return res.json({ items: rows })
    } else {
      const { rows } = await pool.query('SELECT id, name, description, category, price FROM products ORDER BY created_at DESC')
      return res.json({ items: rows })
    }
  }catch(err){
    console.error(err)
    res.status(500).json({ error:'Failed to fetch products' })
  }
})

r.get('/:id', async (req,res)=>{
  try{
    const { rows } = await pool.query('SELECT id, name, description, category, price FROM products WHERE id=$1', [req.params.id])
    const p = rows[0]
    if(!p) return res.status(404).json({ error:'Not found' })
    res.json(p)
  }catch(err){
    console.error(err)
    res.status(500).json({ error:'Failed to fetch product' })
  }
})

export default r
