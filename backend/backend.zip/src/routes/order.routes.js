import { Router } from 'express'
const r = Router()
r.get('/', (req,res)=> res.json({ items: [] }))
r.post('/', (req,res)=> res.json({ id: 'demo-order' }))
export default r
