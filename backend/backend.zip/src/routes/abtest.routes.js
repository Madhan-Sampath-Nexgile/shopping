import { Router } from 'express'
const r = Router()

r.get('/metrics', (req,res)=>{
  const now = Date.now()
  const pts = Array.from({length:10}).map((_,i)=>({ t: new Date(now-(9-i)*3600_000).toLocaleTimeString(), A: 2+i*0.1, B: 2.5+i*0.12 }))
  res.json({ timeseries: pts })
})

export default r
