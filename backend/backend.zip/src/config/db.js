import pkg from 'pg'
const { Pool } = pkg

const pool = new Pool({
  user:  'postgres',
  host:  'localhost',
  database: 'postgres',
  password:  '123456',
  port: parseInt(process.env.DB_PORT || '5432', 10),
})

pool.on('connect', ()=> console.log('🟢 Connected to PostgreSQL'))
pool.on('error', (err)=> console.error('🔴 DB error:', err))

export default pool
